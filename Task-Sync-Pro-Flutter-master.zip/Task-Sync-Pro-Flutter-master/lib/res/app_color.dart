import 'dart:ui';

const primaryColor = Color(0xff151414);
const black = Color(0xff0C090A);