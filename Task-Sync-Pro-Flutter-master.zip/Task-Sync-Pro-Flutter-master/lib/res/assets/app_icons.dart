class AppIcon{
  static const menu='assets/icons/menu.svg';
  static const search='assets/icons/search.svg';
}