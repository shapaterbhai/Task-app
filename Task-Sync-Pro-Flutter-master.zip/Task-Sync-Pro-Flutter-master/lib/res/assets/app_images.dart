class AppImage {
  static const back1='assets/images/back1.jpg';
  static const back2='assets/images/back2.jpg';
  static const back3='assets/images/back3.jpg';
  static const splash='assets/images/splash.png';
}