import 'package:flutter/material.dart';

const Color customRedColor = Color.fromRGBO(229, 62, 62, 1.0);
const Color customGreyColor = Color.fromRGBO(113, 128, 150, 1);
