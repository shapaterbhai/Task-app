package dev.etornam.tasky

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
